﻿# XClone - Guía de uso

Bienvenido a la aplicación. A continuación se explica cómo utilizar cada una de sus funciones.

---

## Inicio de sesión

Al abrir la aplicación puedes iniciar sesión introduciendo:

- Nombre de usuario  
- Contraseña  

Si no tienes cuenta, deberás registrarte primero.

---

## Registro

Pulsa el botón **Registrar** y completa los siguientes datos:

- Nombre  
- Gmail  
- Nombre de usuario  
- Contraseña  

Una vez registrado, vuelve al inicio de sesión e introduce tus credenciales.

---

## Dentro de la aplicación

Cuando accedes:

- En el centro verás todos los tweets (tuyos y de otros usuarios)  
- Puedes publicar nuevos tweets  
- Puedes borrar tus tweets  
- Puedes eliminar tu cuenta  
- Puedes cerrar sesión  

---

## Borrar tweet

1. Selecciona el tweet haciendo clic sobre él  
2. Pulsa el botón **Borrar**

---

## Borrar cuenta

1. La aplicación pedirá confirmación  
2. Pulsa **Sí** para eliminarla definitivamente  

---

## Cerrar sesión

Pulsa el botón de **Cerrar sesión**  
La aplicación te redirigirá a la pantalla de inicio de sesión.

---

## Publicar tweets

1. Escribe el contenido en el cuadro de texto inferior  
2. Pulsa el botón **Publicar**

---

## Nota importante

La aplicación requiere que el backend esté en funcionamiento para operar correctamente.

## Ejecutable

El ejecutable de la aplicación se encuentra en:

`XCloneDesktop/bin/Release/`

Para ejecutarlo:
1. Acceder a esa carpeta
2. Ejecutar el archivo `.exe`

Alternativamente, se puede ejecutar desde Visual Studio abriendo la solución del proyecto.

## Importante

La aplicación requiere que el backend esté en funcionamiento en:

http://localhost:8080/xapi/rest/

Si el servidor no está activo, la aplicación no funcionará correctamente.