<?php require __DIR__ . '/../layout/header.php'; ?>
<?php $user = $_SESSION['user']; ?>

<section class="grid">
  <div class="card">
    <h2>Publicar</h2>

    <?php if (!empty($error)): ?>
      <p class="alert"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="post" action="/?r=postTweet" class="form">
      <textarea name="content" rows="4" maxlength="280" placeholder="Que está pasando?" required></textarea>
      <button type="submit">Post</button>
    </form>

    <p class="muted">
      Logueado como <strong><?= htmlspecialchars($user['username']) ?></strong>
      <span class="muted">@<?= htmlspecialchars($user['username']) ?></span>
    </p>
  </div>

  <div class="card">
    <h2>Timeline</h2>

    <?php if (empty($tweets)): ?>
      <p class="muted">Sen posts aínda. O baleiro, como na alma do proxecto.</p>
    <?php else: ?>
      <?php foreach ($tweets as $t): ?>
        <article class="tweet">
          <div class="tweet-head">
            <strong><?= htmlspecialchars($t['username'] ?? 'user') ?></strong>
            <span class="muted"><?= htmlspecialchars($t['handle'] ?? '') ?></span>
          </div>

          <p><?= nl2br(htmlspecialchars($t['content'] ?? '')) ?></p>

          <?php if (($t['username'] ?? '') === ($user['username'] ?? '')): ?>
            <a class="delete-btn"
              href="/?r=home&delete_id=<?= htmlspecialchars($t['id']) ?>"
              onclick="return confirm('Borrar este tweet?');">
              🗑 Borrar
            </a>
          <?php endif; ?>
        </article>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</section>

<?php require __DIR__ . '/../layout/footer.php'; ?>