<?php require __DIR__ . '/../layout/header.php'; ?>

<section class="card">
    <h1>Iniciar sesión</h1>

    <?php if (!empty($error)): ?>
        <p class="alert"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="post" action="?r=doLogin" class="form">
        <label>Username
            <input name="username" required>
        </label>

        <label>Password
            <input name="password" type="password" required>
        </label>

        <button type="submit">Entrar</button>
    </form>

    <p class="muted">Non tes conta? <a class="link" href="/?r=register">Rexístrate</a></p>
</section>

<?php require __DIR__ . '/../layout/footer.php'; ?>