<?php require __DIR__ . '/../layout/header.php'; ?>

<section class="card">
    <h1>Rexistro</h1>

    <?php if (!empty($error)): ?>
        <p class="alert"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="post" action="?r=doRegister" class="form">
        <label>Username
            <input name="username" required>
        </label>

        <label>Email
            <input name="email" type="email" required>
        </label>

        <label>Nome público (display_name)
            <input name="display_name" placeholder="Opcional">
        </label>

        <label>Password
            <input name="password" type="password" required>
        </label>

        <button type="submit">Crear conta</button>
    </form>

    <p class="muted">Xa tes conta? <a class="link" href="/?r=login">Login</a></p>
</section>

<?php require __DIR__ . '/../layout/footer.php'; ?>