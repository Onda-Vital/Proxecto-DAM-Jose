<?php $user = $_SESSION['user'] ?? null; ?>
<!doctype html>
<html lang="gl">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>X clone mini</title>
    <link rel="stylesheet" href="assets/style.css">
</head>

<body>
    <header class="topbar">
        <div class="brand">Xclone</div>
        <nav>
            <?php if ($user): ?>
                <span class="muted"><?= htmlspecialchars($user['display_name'] ?? $user['username'] ?? 'user') ?></span>
                <a class="link" href="?r=logout">Saír</a>
            <?php else: ?>
                <a class="link" href="/?r=login">Login</a>
                <a class="link" href="/?r=register">Rexistro</a>
            <?php endif; ?>
        </nav>
    </header>
    <main class="container">