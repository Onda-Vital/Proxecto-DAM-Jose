<?php

class ApiClient
{
    private string $base;

    public function __construct(string $base)
    {
        $this->base = rtrim($base, '/');
    }

    public function get(string $path): array
    {
        return $this->request('GET', $path);
    }

    public function post(string $path, array $payload): array
    {
        return $this->request('POST', $path, $payload);
    }

    private function request(string $method, string $path, ?array $payload = null): array
    {
        $url = $this->base . '/' . ltrim($path, '/');

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);

        $headers = ['Accept: application/json'];

        if ($payload !== null) {
            $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
        }

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $body = curl_exec($ch);
        $err  = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false) {
            return ['ok' => false, 'code' => 0, 'data' => null, 'error' => $err ?: 'Erro cURL'];
        }

        $data = json_decode($body, true);
        // Se non é JSON válido, gardamos o texto
        if (json_last_error() !== JSON_ERROR_NONE) {
            $data = $body;
        }

        $ok = ($code >= 200 && $code < 300);

        return [
            'ok' => $ok,
            'code' => $code,
            'data' => $data,
            'error' => $ok ? null : (is_array($data) && isset($data['error']) ? $data['error'] : 'Erro HTTP ' . $code)
        ];
    }

    public function delete(string $path): array
    {
        return $this->request('DELETE', $path);
    }
}
