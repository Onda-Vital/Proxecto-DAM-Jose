<?php

class HomeController
{
    private ApiClient $api;

    public function __construct(ApiClient $api)
    {
        $this->api = $api;
    }

    private function requireAuth(): void
    {
        if (!isset($_SESSION['user'])) {
            header('Location: /?r=login');
            exit;
        }
    }

    public function index(array $params = []): void
    {
        $this->requireAuth();

        $error = $params['error'] ?? null;

        // GET /tweet lista :contentReference[oaicite:9]{index=9}
        $res = $this->api->get('/tweet');
        $tweets = $res['ok'] && is_array($res['data']) ? $res['data'] : [];

        require __DIR__ . '/../views/home/index.php';
    }

    public function postTweet(): void
    {
        $this->requireAuth();

        $content = trim($_POST['content'] ?? '');
        if ($content === '') {
            $this->index(['error' => 'Escribe algo antes de publicar.']);
            return;
        }

        $user = $_SESSION['user'];
        $username = $user['username'] ?? 'anon';
        $handle = '@' . $username;

        // POST /tweet crea :contentReference[oaicite:10]{index=10}
        $res = $this->api->post('/tweet', [
            'username' => $username,
            'handle' => $handle,
            'content' => $content
        ]);

        if (!$res['ok']) {
            $this->index(['error' => 'Non se puido publicar.']);
            return;
        }

        header('Location: /?r=home');
        exit;
    }
}
