<?php

class AuthController
{
    private ApiClient $api;

    public function __construct(ApiClient $api)
    {
        $this->api = $api;
    }

    public function showLogin(array $params = []): void
    {
        $error = $params['error'] ?? null;
        require __DIR__ . '/../views/auth/login.php';
    }

    public function showRegister(array $params = []): void
    {
        $error = $params['error'] ?? null;
        require __DIR__ . '/../views/auth/register.php';
    }

    public function login(): void
    {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if ($username === '' || $password === '') {
            $this->showLogin(['error' => 'Faltan username/password.']);
            return;
        }

        // Segundo a túa API: POST /user/login con username e password :contentReference[oaicite:6]{index=6}
        $res = $this->api->post('/user/login', [
            'username' => $username,
            'password' => $password
        ]);

        if (!$res['ok']) {
            $this->showLogin(['error' => 'Login incorrecto.']);
            return;
        }

        // Garda usuario en sesión (a API devolve id, username, email, display_name) :contentReference[oaicite:7]{index=7}
        $_SESSION['user'] = $res['data'];
        header('Location: /?r=home');
        exit;
    }

    public function register(): void
    {
        $username = trim($_POST['username'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $display  = trim($_POST['display_name'] ?? '');

        if ($username === '' || $email === '' || $password === '') {
            $this->showRegister(['error' => 'username, email e password son obrigatorios.']);
            return;
        }

        // POST /user crea usuario :contentReference[oaicite:8]{index=8}
        $res = $this->api->post('/user/', [
            'username' => $username,
            'email' => $email,
            'password' => $password,
            'display_name' => ($display === '' ? $username : $display)
        ]);

        if (!$res['ok']) {
            $this->showRegister(['error' => 'Non se puido rexistrar: ' . ($res['error'] ?? 'erro')]);
            return;
        }

        // Auto-login tras rexistro
        $_SESSION['user'] = $res['data'];
        header('Location: /?r=home');
        exit;
    }

    public function logout(): void
    {
        // Se a sesión existe, limpa todo
        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION = [];

            // Borra a cookie da sesión (importante)
            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(
                    session_name(),
                    '',
                    time() - 42000,
                    $params["path"],
                    $params["domain"],
                    $params["secure"],
                    $params["httponly"]
                );
            }

            session_destroy();
        }

        header('Location: ?r=login');
        exit;
    }
}
