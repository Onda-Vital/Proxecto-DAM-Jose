<?php
session_start();

$config = require __DIR__ . '/../app/config/config.php';
require __DIR__ . '/../app/models/ApiClient.php';
require __DIR__ . '/../app/controllers/AuthController.php';
require __DIR__ . '/../app/controllers/HomeController.php';

$api = new ApiClient($config['api_base']);
// BORRAR TWEET
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];

    $ok = $api->delete('/tweet/' . urlencode($id));
    $_SESSION['flash'] = $ok ? 'Tweet borrado.' : 'Erro borrando tweet.';

    header('Location: /?r=home');
    exit;
}
$auth = new AuthController($api);
$home = new HomeController($api);

$route = $_GET['r'] ?? 'home';

switch ($route) {
    case 'login':
        $auth->showLogin();
        break;
    case 'doLogin':
        $auth->login();
        break;
    case 'register':
        $auth->showRegister();
        break;
    case 'doRegister':
        $auth->register();
        break;
    case 'logout':
        $auth->logout();
        break;
    case 'home':
        $home->index();
        break;
    case 'postTweet':
        $home->postTweet();
        break;
    default:
        http_response_code(404);
        echo "404 - ruta inexistente";
}
